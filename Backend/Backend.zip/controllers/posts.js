import Post from "../models/Post.js";
import User from "../models/User.js";

/* CREATE */
export const createPost = async (req, res) => {
    try {
        const { userId, author, heading, description, filePath } = req.body;
        const user = await User.findById(userId);
        const newPost = new Post({
            userId,
            firstName: user.firstName,
            lastName: user.lastName,
            description,
            filePath,
            heading,
            author,
            comments: [],
        });
        await newPost.save();

        const post = await Post.find().sort({ createdAt: -1 });
        res.status(201).json(post);
    } catch (err) {
        res.status(409).json({ message: err.message });
    }
};

/* READ */
export const getFeedPosts = async (req, res) => {
    try {
        const post = await Post.find()
            .populate("userId", "firstName lastName picturePath")
            .sort({ createdAt: -1 });
        res.status(200).json(post);
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

/* READ */
export const getSinglePosts = async (req, res) => {
    try {
        const { postId } = req.params;
        const post = await Post.findById(postId);
        res.status(201).json(post);
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

export const getUserPosts = async (req, res) => {
    try {
        const { userId } = req.params;
        const post = await Post.find({ userId })
            .populate("userId", "firstName lastName picturePath")
            .sort({ createdAt: -1 });
        res.status(200).json(post);
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

/* UPDATE */
export const addComment = async (req, res) => {
    try {
        const postId = req.params.postId;
        const commentData = req.body; 

        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).json({ message: "Post not found" });
        }

        post.Comments.push(commentData);

        await post.save();

        return res
            .status(201)
            .json({ message: "Comment added successfully", post });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal Server Error" });
    }
};

/* DELETE */
export const deletePost = async (req, res) => {
    try {
        const { id } = req.params;
        await Post.findByIdAndDelete(id);

        const post = await Post.find().sort({ createdAt: -1 });
        res.status(201).json(post);
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

// /* CREATE */
// export const createPost = async (req, res) => {
//     try {
//         const { userId, description, picturePath } = req.body;
//         const user = await User.findById(userId);
//         const newPost = new Post({
//             userId,
//             firstName: user.firstName,
//             lastName: user.lastName,
//             location: user.location,
//             description,
//             userPicturePath: user.picturePath,
//             picturePath,
//             likes: {},
//             comments: [],
//         });
//         await newPost.save();

//         const post = await Post.find().sort({ createdAt: -1 });
//         res.status(201).json(post);
//     } catch (err) {
//         res.status(409).json({ message: err.message });
//     }
// };

// /* READ */
// export const getFeedPosts = async (req, res) => {
//     try {
//         const post = await Post.find().sort({ createdAt: -1 });
//         res.status(200).json(post);
//     } catch (err) {
//         res.status(404).json({ message: err.message });
//     }
// };

// /* READ */
// export const getSinglePosts = async (req, res) => {
//     try {
//         const { postId } = req.params;
//         const post = await Post.findById({ _id: postId });
//         res.status(201).json(post);
//     } catch (err) {
//         res.status(404).json({ message: err.message });
//     }
// };

// export const getUserPosts = async (req, res) => {
//     try {
//         const { userId } = req.params;
//         const post = await Post.find({ userId }).sort({ createdAt: -1 });
//         res.status(200).json(post);
//     } catch (err) {
//         res.status(404).json({ message: err.message });
//     }
// };

// /* UPDATE */
// export const likePost = async (req, res) => {
//     try {
//         const { id } = req.params;
//         const { userId } = req.body;
//         const post = await Post.findById(id);
//         const isLiked = post.likes.get(userId);

//         if (isLiked) {
//             post.likes.delete(userId);
//         } else {
//             post.likes.set(userId, true);
//         }

//         const updatedPost = await Post.findByIdAndUpdate(
//             id,
//             { likes: post.likes },
//             { new: true }
//         );

//         res.status(200).json(updatedPost);
//     } catch (err) {
//         res.status(404).json({ message: err.message });
//     }
// };

// /* DELETE */
// export const deletePost = async (req, res) => {
//     try {
//         const { id } = req.params;
//         await Post.findByIdAndDelete({ _id: id });

//         const post = await Post.find().sort({ createdAt: -1 });
//         res.status(201).json(post);
//     } catch (err) {
//         res.status(404).json({ message: err.message });
//     }
// };
