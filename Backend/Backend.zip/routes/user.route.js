import express from "express";
import {
    getUser,
    getAllSearchUsers
} from "../controllers/users.js";
import { verifyToken } from "../middleware/auth.js";

const userRouter = express.Router();

/* READ */
userRouter.get("/:id", verifyToken, getUser);

/* SEARCH USERS */
userRouter.get("/:searchQuery/search", verifyToken, getAllSearchUsers);

export { userRouter };
